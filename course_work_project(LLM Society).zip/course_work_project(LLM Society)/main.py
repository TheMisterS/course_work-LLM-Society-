import logging
from logger import setup_logger

# TEMP/TEST imports
from graph.graph_factory import initialize_state
from graph.utils.prompts import build_system_prompt, build_user_prompt
if __name__ == "__main__":
    setup_logger()
    logger = logging.getLogger(__name__)
    logger.info("Starting the LLM Society application")
    #graph = build_graph()



    # TESTING

    # Test state initialization
    # state = initialize_state()
    # print(state)

    # Test prompt building
    # state = initialize_state()
    # for agent_name, agent_state in state["agents"].items():
    #     sys_prompt = build_system_prompt(agent_state)
    #     user_prompt = build_user_prompt(agent_state)
    #     print(f"System Prompt for {agent_name}:\n{sys_prompt}\n")
    #     print("----------------------------------------------------\n")
    #     print(f"User Prompt for {agent_name}:\n{user_prompt}\n")
    #     print("----------------------------------------------------\n")

