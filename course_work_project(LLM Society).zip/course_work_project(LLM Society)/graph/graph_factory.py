from langgraph.graph import StateGraph, END

from configs.agent_config import AGENT_PROFILES
from configs.models_config import MODEL_PROFILES
from configs.simulation_config import DEBATE_TOPIC
from graph.utils.state import AgentState, GraphState
from graph.chain_factory import configure_model
def initialize_state():
    state = GraphState()
    state["agents"] = {}
    state["models"] = {}

    # Initialize agents
    for agent_name, profile in AGENT_PROFILES.items():
        agent_state = AgentState(
            name=agent_name,
            role_desc=profile["role_desc"],
            traits=profile["traits"],
            long_mem=[],
            short_mem=[],
            agent_agenda={"debate_topic": DEBATE_TOPIC}
        )
        state["agents"][agent_name] = agent_state

    # Initialize models
    for model_number, profile in MODEL_PROFILES.items():
        state["models"][model_number] = configure_model(profile)

    # Initialize other attributes
    state["round"] = 0
    state["phase"] = "debate"
    state["supervisor_notes"] = []
    state["agenda"] = {"debate_topic": DEBATE_TOPIC}
    state["votes"] = {}

    return state

def build_graph(state: GraphState = None):
    workflow = StateGraph(state, reducers=None)

    
    # workflow.add_node("supervisor", supervisor)
    # workflow.add_node("agent_speak", agent_speak)
    # workflow.add_node("remember", remember)
    # workflow.add_node("role_shift", role_shift)
    # workflow.add_node("vote", vote)
    # workflow.add_node("tick", tick)

    # workflow.add_edge(START, "supervisor")
    # workflow.add_conditional_edge("supervisor",
    #   route_after_supervisor,
    #    "role_shift": "role_shift",
    #    "vote": "vote"
    #    "agent_speak": "agent_speak"
    #)
    # workflow.add_edge("role_shift", "tick")
    # workflow.add_edge("vote", "tick")
    # workflow.add_edge("agent_speak", "remember")
    # workflow.add_edge("remember", router)
    # workflow.add_edge("tick", "supervisor")
    ...
    graph = workflow.compile()

    return graph



