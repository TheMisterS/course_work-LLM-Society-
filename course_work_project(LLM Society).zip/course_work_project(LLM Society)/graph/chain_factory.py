from configs.models_config import MODEL_PROFILES, OLLAMA_URL
from langchain_community.chat_models import ChatOllama
from langchain_core.prompts import ChatPromptTemplate

import logging
logger = logging.getLogger(__name__)

def configure_model(model_kwargs=MODEL_PROFILES, base_url=OLLAMA_URL):
    if not MODEL_PROFILES:
        logger.error("MODEL_KWARGS is not defined.")
    logger.info(f"Creating ChatOllama model with model  {model_kwargs["model"]}")

    model = ChatOllama(**model_kwargs)
    return model


def create_agent_chain(model, sys_prompt, user_prompt):
    logger.info("Creating agent chain with provided prompts.")
    prompt = ChatPromptTemplate.from_messages([
        ("system", sys_prompt),
        ("user", user_prompt)
    ])

    chain = prompt | model
    #(WIP) might need a parser here
    return chain
