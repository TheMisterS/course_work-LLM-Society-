

import os
from dotenv import load_dotenv

load_dotenv()

DEBATE_TOPIC = os.environ.get("DEBATE_TOPIC", "The impact of artificial intelligence on society.")